#include <ros/ros.h>
#include <geometry_msgs/Twist.h>
#include <math.h>

int main(int argc, char **argv)
{
  ros::init(argc, argv, "mobileRobotControl");
  ros::NodeHandle nh;
  ros::Publisher pub = nh.advertise<geometry_msgs::Twist>("/cmd_vel", 1000);
  ros::Rate loop_rate(5);
  geometry_msgs::Twist msg;
  
  msg.linear.x = 1;
  msg.angular.z = M_PI;

  while(ros::ok()){
    pub.publish(msg);
    loop_rate.sleep();
  }
  return 0;
}

